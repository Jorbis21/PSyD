#include <s3c44b0x.h>
#include <s3cev40.h>
#include <common_types.h>
#include <system.h>
#include <segs.h>
#include <timers.h>
#include <lcd.h>
#include <pbs.h>
#include <keypad.h>
/* Nmero mximo de fotos distintas visualizables en el marco */

#define MAX_PHOTOS (40)

/* Direcciones en donde se encuentran cargados los BMPs tras la ejecucin del comando "script load_bmp.script" */

#define ARBOL       ((uint8 *)0x0c210000)
#define PICACHU     ((uint8 *)0x0c220000)
#define PAGARC24   ((uint8 *)0x0c360000)
#define ORBIS ((uint8 *)0x0c368000)

#define a		((uint8 *)0x0c230000)
#define Amongos     ((uint8 *)0x0c240000)
#define DIVIDIR     ((uint8 *)0x0c250000)
#define Esmiaeh     ((uint8 *)0x0c260000)
#define geralt	((uint8 *)0x0c270000)
#define Hada     	((uint8 *)0x0c280000)
#define Horfanato   ((uint8 *)0x0c290000)
#define JordiWild   ((uint8 *)0x0c300000)
#define Perro     	((uint8 *)0x0c310000)
#define Pou     	((uint8 *)0x0c320000)
#define SePuede     ((uint8 *)0x0c340000)
#define carrera	((uint8 *)0x0c350000)
/* Dimensiones de la pantalla para la realizacin de efectos */

#define LCD_COLS   (LCD_WIDTH/2)        // Para simplificar el procesamiento consideraremos una columna como la formada por 2 pxeles adyacentes (1 byte)
#define LCD_ROWS   (LCD_HEIGHT)

/* Sentidos de realizacin del efecto */

#define LEFT       (0)
#define RIGHT      (1)
#define UP         (2)
#define DOWN       (3)
#define NO_APPLY   (4)

/* Declaracin de funciones auxiliares */

void lcd_putBmp(uint8 *bmp, uint16 x, uint16 y, uint16 xsize, uint16 ysize);
void lcd_bmp2photo(uint8 *bmp, uint8 *photo);
void test(uint8 *photo); // Incluida para uso exclusivo en depuracin, deber eliminarse del proyecto final
void lcd_full_color(uint16 color);
void lcd_putColumn(uint16 xLcd, uint8 *photo, uint16 xPhoto);
void lcd_putRow(uint16 yLcd, uint8 *photo, uint16 yPhoto); // Deber recodificarse en el proyecto final
void lcd_putPhoto(uint8 *photo);    // Deber recodificarse en el proyecto final
void photosMaxColor(uint8* photo, uint8* aux, uint16 color);
void lcd_putPartColumn(int16 col, int16 rowOri, int16 rowDest, uint8* photo);
void lcd_putPartRow(int16 row, int16 colOri, int16 colDest, uint8* photo);
void putSquare(int x, int y, int tam, uint8 *photo);
void lcd_shift(uint8 sense, uint16 colOrig, uint16 colDest, uint16 rowOrig, uint16 rowDest);
//void lcd_shift(uint8 sense, uint16 colOrig, uint16 colDest, uint16 rowOrig,uint16 rowDest, uint8 mode); // Deber completarse y ampliarse en el proyecto final

/* Declaracin de efectos de transicin entre fotos */

void efectoNulo(uint8 *photo, uint8 sense);
void efectoEmpuje(uint8 *photo, uint8 sense); // Deber completarse en el proyecto final
void efectoBarrido(uint8 *photo, uint8 sense); // Deber implementarse en el proyecto final
void efectoRevelado(uint8 *photo, uint8 sense); // Deber implementarse en el proyecto final
void efectoCobertura(uint8 *photo, uint8 sense); // Deber implementarse en el proyecto final

// Otros posibles efectos a implementar
void efectoDivisionEntrante(uint8 *photo, uint8 sense);
void efectoDivisionSaliente(uint8 *photo, uint8 sense);
void efectoCuadradoEntrante(uint8 *photo, uint8 sense);
void efectoCuadradoSaliente(uint8 *photo, uint8 sense);
void efectoBarras(uint8 *photo, uint8 sense);
void efectoDisolver(uint8 *photo, uint8 sense);
void efectoFlash(uint8 *photo, uint8 sense);
void efectoDesvanecer(uint8 *photo, uint8 sense);
void efectoCruz(uint8 *photo, uint8 sense);
void efectoAleatorio(uint8 *photo, uint8 sense);

/* Declaracin de tipos */

typedef void (*pf_t)(uint8 *, uint8); // Tipo puntero a una funcin efecto con 2 argumentos (foto y sentido del efecto)

typedef struct // Estructura con toda la informacin (pack) relativa a la visualizacin de una foto, podr ampliarse segn convenga
{
	uint8 photo[LCD_BUFFER_SIZE];          // Foto
	pf_t effect;             // Efecto de transicin a aplicar para visualizarla
	//uint8 sense;                           // Sentido del efecto a aplicar
	uint8 secs;                           // Segundos que debe estar visualizada
} pack_t;

typedef struct // Estructura conteniendo las fotos a visualizar, podr ampliarse segn convenga
{
	uint8 numPacks;                     // Nmero de packs que contiene el album
	pack_t pack[MAX_PHOTOS];               // Array de fotos
} album_t;

/* Declaracin del buffer de vdeo */

extern uint8 lcd_buffer[LCD_BUFFER_SIZE];

//recursos para la velocidad de transici�n
volatile uint8 delay = 2;
void isr_pbs(void) __attribute__ ((interrupt ("IRQ")));
volatile boolean flagPbs;

//recursos para el cambio de efecto
volatile boolean flagKeypad;
void isr_keypad(void) __attribute__ ((interrupt ("IRQ")));
volatile pf_t efecto=NULL;
void (*functions[15])(uint8 *, uint8);
pf_t functions[15] = { efectoBarras, efectoBarrido, efectoCobertura, efectoCruz,
		efectoCuadradoEntrante, efectoCuadradoSaliente, efectoDesvanecer, efectoDisolver,
		efectoDivisionEntrante, efectoDivisionSaliente, efectoEmpuje, efectoFlash,
		efectoNulo, efectoRevelado, efectoAleatorio };

/*******************************************************************/
static volatile int seed = 1;
int rand(void);
volatile boolean stop=FALSE;

void main(void) {
	album_t album;
	uint16 i;
	uint8 sentido=0;

	sys_init();
	segs_init();
	timers_init();
	lcd_init();
	pbs_init();
	keypad_init();

	lcd_clear();
	lcd_on();

	keypad_open(isr_keypad);
	flagKeypad = FALSE;

	// Ejemplo de uso de las miniaturas (de este o distinto tamao)

	lcd_putBmp(ORBIS, 20, 20, 128, 96);
	lcd_putBmp(PAGARC24, 168, 20, 128, 96);

	lcd_puts(20, 130, BLACK, "Proyecto Final PSyD");
	lcd_puts(20,146, BLACK, "Javier Orbis Ramirez");
	lcd_puts(20, 162, BLACK, "Pablo Garcia Fernandez");
	lcd_puts(20,178,BLACK,"Pulse cualquier tecla para empezar...");
	while(!keypad_pressed());

	// Creacin del album de fotos

	i = 0;

	lcd_bmp2photo(ARBOL, album.pack[i].photo);
	album.pack[i].secs = 1;
	album.pack[i].effect = functions[i];
	i++;

	lcd_bmp2photo(a, album.pack[i].photo);
	album.pack[i].secs = 3;
	album.pack[i].effect = functions[i];
	i++;

	lcd_bmp2photo(PICACHU, album.pack[i].photo);
	album.pack[i].secs = 3;
	album.pack[i].effect = functions[i];
	i++;

	lcd_bmp2photo(Amongos, album.pack[i].photo);
	album.pack[i].secs = 3;
	album.pack[i].effect = functions[i];
	i++;

	lcd_bmp2photo(DIVIDIR, album.pack[i].photo);
	album.pack[i].secs = 3;
	album.pack[i].effect = functions[i];
	i++;

	lcd_bmp2photo(Esmiaeh, album.pack[i].photo);
	album.pack[i].secs = 3;
	album.pack[i].effect = functions[i];
	i++;

	lcd_bmp2photo(geralt, album.pack[i].photo);
	album.pack[i].secs = 3;
	album.pack[i].effect = functions[i];
	i++;

	lcd_bmp2photo(Hada, album.pack[i].photo);
	album.pack[i].secs = 3;
	album.pack[i].effect = functions[i];
	i++;

	lcd_bmp2photo(Horfanato, album.pack[i].photo);
	album.pack[i].secs = 3;
	album.pack[i].effect = functions[i];
	i++;

	lcd_bmp2photo(JordiWild, album.pack[i].photo);
	album.pack[i].secs = 3;
	album.pack[i].effect = functions[i];
	i++;

	lcd_bmp2photo(Perro, album.pack[i].photo);
	album.pack[i].secs = 3;
	album.pack[i].effect = functions[i];
	i++;

	lcd_bmp2photo(Pou, album.pack[i].photo);
	album.pack[i].secs = 3;
	album.pack[i].effect = functions[i];
	i++;

	lcd_bmp2photo(SePuede, album.pack[i].photo);
	album.pack[i].secs = 3;
	album.pack[i].effect = functions[i];
	i++;

	lcd_bmp2photo(carrera, album.pack[i].photo);
	album.pack[i].secs = 3;
	album.pack[i].effect = functions[i];
	i++;

	album.numPacks = i;
	// Carrusel de fotos demostrando que solo los efectos por DMA hacen transiciones aceptables

	i = 0;

	pbs_open(isr_pbs);
	flagPbs = FALSE;

	efecto = NULL;
	stop=FALSE;

	while (1) {
		album.pack[i].effect=efecto==NULL?album.pack[i].effect:efecto;//para la demo, o mantiene su efecto inicial o el usuario ya lo ha cambiado
		(*album.pack[i].effect)(album.pack[i].photo, sentido=(sentido+1)%4);
		sw_delay_s(album.pack[i].secs);
		i = (i == album.numPacks - 1 ? 0 : i + 1);
		while(stop);
	}

	pbs_close();
	keypad_close();
}

int rand(void){
	seed=seed*1103515245+12345;
	return (unsigned int)(seed/65536)%32767+1;
}
/*******************************************************************/

/*
 ** Muestra un BMP de tamao (xsize, ysize) pxeles en la posicin (x,y) del LCD
 ** Esta funcin es una generalizacin de lcd_putWallpaper() ya que:
 **     lcd_putWallpaper( bmp ) = lcd_putBmp( bmp, 0, 0, LCD_WIDTH, LCD_HEIGHT )
 **
 ** NO puede hacerse por DMA porque requiere la manipulacin de pixeles
 */

void lcd_putBmp(uint8 *bmp, uint16 x, uint16 y, uint16 xsize, uint16 ysize) {
	uint32 headerSize;

	uint16 xSrc, ySrc, yDst;
	uint16 offsetSrc, offsetDst;

	headerSize = bmp[10] + (bmp[11] << 8) + (bmp[12] << 16) + (bmp[13] << 24);

	bmp = bmp + headerSize;

	for (ySrc = 0, yDst = ysize - 1; ySrc < ysize; ySrc++, yDst--) {
		offsetDst = (yDst + y) * LCD_WIDTH / 2 + x / 2;
		offsetSrc = ySrc * xsize / 2;
		for (xSrc = 0; xSrc < xsize / 2; xSrc++)
			lcd_buffer[offsetDst + xSrc] = ~bmp[offsetSrc + xSrc];
	}
}

/*
 ** Respecto al buffer de vdeo, el formato BMP tiene cabecera, las filas estn volteadas y el color invertido,
 ** Esta funcin convierte los BMP en un array de pixeles directamente visualizable (foto) para facilitar su manipulacin
 ** Es una adaptacin de lcd_putWallpaper() que en lugar de copiar el BMP sobre el buffer de vdeo lo hace sobre el array photo
 **
 ** NO puede hacerse por DMA porque requiere la manipulacin de pixeles.
 */

void lcd_bmp2photo(uint8 *bmp, uint8 *photo) {
	uint32 headerSize;

	uint16 x, ySrc, yDst;
	uint16 offsetSrc, offsetDst;

	headerSize = bmp[10] + (bmp[11] << 8) + (bmp[12] << 16) + (bmp[13] << 24); // Los datos de cabecera estn en little-endian

	bmp = bmp + headerSize;                                    // Salta cabecera

	for (ySrc = 0, yDst = LCD_HEIGHT - 1; ySrc < LCD_HEIGHT; ySrc++, yDst--) // Voltea verticalmente e invierte los pixels
			{
		offsetDst = yDst * LCD_WIDTH / 2;
		offsetSrc = ySrc * LCD_WIDTH / 2;
		for (x = 0; x < LCD_WIDTH / 2; x++)
			photo[offsetDst + x] = ~bmp[offsetSrc + x];
	}
}

/*
 ** Chequea que se est visualizando la foto indicada comparando pixel a pixel el buffer de vdeo y la foto
 ** Incluida para uso exclusivo en depuracin, deber eliminarse del proyecto final
 **
 ** NO puede hacerse por DMA porque requiere la comparacin de pixeles.
 */

void test(uint8 *photo) {
	int16 x, y;

	for (x = 0; x < LCD_COLS; x++)
		for (y = 0; y < LCD_ROWS; y++)
			if (lcd_buffer[y * LCD_COLS + x] != photo[y * LCD_COLS + x]) {
				segs_putchar(0xE);
				while (1)
					;
			}
}

/*
 ** Visualiza una columna de la foto en una columna dada de la pantalla
 **
 ** NO puede hacerse por DMA porque los pixeles de una columna no ocupan posiciones contiguas de memoria
 */

void lcd_putColumn(uint16 xLcd, uint8 *photo, uint16 xPhoto) {
	int16 y;

	for (y = 0; y < LCD_ROWS; y++)
		lcd_buffer[(y * LCD_COLS) + xLcd] = photo[(y * LCD_COLS) + xPhoto];
}

/*
 ** Visualiza una linea de la foto en una linea dada de la pantalla
 **
 ** Deber recodificarse para que se realice mediante una nica operacin DMA ya que los pixeles de una linea son contiguos en memoria
 */

void lcd_putRow(uint16 yLcd, uint8 *photo, uint16 yPhoto) {
	int16 x;

	for (x = 0; x < LCD_COLS; x++)
		lcd_buffer[(yLcd * LCD_COLS) + x] = photo[(yPhoto * LCD_COLS) + x];
}

/*
 ** Visualiza una foto en la pantalla
 **
 ** Deber recodificarse para que se realice mediante una nica operacin DMA ya que los pixeles de una imagen son contiguos en memoria
 */

void lcd_putPhoto(uint8 *photo) {
	int16 x, y;

	for (y = 0; y < LCD_ROWS; y++)
		for (x = 0; x < LCD_COLS; x++)
			lcd_buffer[(y * LCD_COLS) + x] = photo[(y * LCD_COLS) + x];
}

/*
 ** Scroll de una fila/columna por DMA
 ** Desplaza el contenido del LCD una linea en desplazamientos verticales, o una columna (formada por 2 pixeles adyacentes) en desplazamientos horizontales
 **
 ** Deber completarse y ampliarse para poder realizar otros efectos
 */
void DMAconfg(uint8 mode, uint32 tam, uint8 *orig, uint8 *dest) {
	ZDISRC0 = (0 << 30) | (mode << 28) | (uint32) orig;
	ZDIDES0 = (2 << 30) | (mode << 28) | (uint32) dest;
	ZDICNT0 = (2 << 28) | (1 << 26) | (0 << 22) | (0 << 21) | (tam);
	ZDICNT0 |= (1 << 20);
	ZDCON0 = 1;
	while (ZDCCNT0 & 0xFFFFF)
		;
}
void lcd_shift(uint8 sense, uint16 colOrig, uint16 colDest, uint16 rowOrig, uint16 rowDest) {
    int16 y;
    switch (sense) {
    case LEFT:
        for (y = rowOrig; y <= rowDest; y++)
            DMAconfg(1, colDest - colOrig, lcd_buffer + ((y * LCD_COLS)+colOrig+1), lcd_buffer + ((y * LCD_COLS)+colOrig));
        break;
    case RIGHT:
        for (y = rowOrig; y <= rowDest; y++)
            DMAconfg( 2, colDest - colOrig, lcd_buffer + ((y * LCD_COLS)+colDest-1), lcd_buffer + ((y * LCD_COLS)+colDest));
        break;
    case UP:
        DMAconfg( 1,LCD_COLS*(rowDest - rowOrig), lcd_buffer + (LCD_COLS * (rowOrig + 1)), lcd_buffer + (LCD_COLS * rowOrig));//lcd_buffer + LCD_COLS, lcd_buffer
        break;
    case DOWN:
        DMAconfg( 2, LCD_COLS*(rowDest - rowOrig), lcd_buffer + (LCD_COLS * rowDest) - 1, lcd_buffer + (LCD_COLS * (rowDest + 1)) - 1);//lcd_buffer + LCD_BUFFER_SIZE - LCD_COLS - 1, lcd_buffer + LCD_BUFFER_SIZE - 1
        break;
    }
}
/*
 ** Efecto cobertura: La nueva imagen se superpone haciendo scroll sobre la imagen mostrada
 */
void efectoCobertura(uint8 *photo, uint8 sense) {
    int16 x;

    switch (sense) {
    case LEFT:
        for (x = LCD_COLS - 1; x >= 0; x--) {
            lcd_shift(LEFT, x, LCD_COLS-1, 0, LCD_ROWS - 1);
            lcd_putColumn(LCD_COLS - 1, photo, LCD_COLS - 1 - x);
            sw_delay_ms(delay);
        }
        break;
    case RIGHT:
        for (x = 0; x < LCD_COLS; x++) {
        	lcd_shift(RIGHT, 0, x, 0, LCD_ROWS - 1);
        	lcd_putColumn(0, photo, LCD_COLS - 1 - x);
        	sw_delay_ms(delay);
        }
        break;
    case UP:
        for (x = LCD_ROWS - 1; x >= 0; x--) {
        	lcd_shift(UP, 0, 0, x, LCD_ROWS - 1);
        	lcd_putRow(LCD_ROWS - 1, photo, LCD_ROWS - 1 - x);
        	sw_delay_ms(delay);
        }
        break;
    case DOWN:
        for (x = 0; x <= LCD_ROWS - 1; x++) {
        	lcd_shift(DOWN, 0, 0, 0, x);
        	lcd_putRow(0, photo, LCD_ROWS - 1 - x);
        	sw_delay_ms(delay);
        }
        break;
    }
}
		/*******************************************************************/

		/*
		 ** Efecto nulo: Muestra la foto sin hacer efecto alguno
		 **
		 ** Incluido por homogeneidad
		 */

void efectoNulo(uint8 *photo, uint8 sense) {
	switch (sense) {
	default:
		lcd_putPhoto(photo);
		break;
	}
}

/*
 ** Efecto empuje: La nueva imagen hace un scroll conjunto con la imagen mostrada
 **
 ** Deber completarse en el proyecto final
 */
//void lcd_shift(uint8 sense, uint16 colOrig, uint16 colDest, uint16 rowOrig, uint16 rowDest)
void efectoEmpuje(uint8 *photo, uint8 sense) {
    int16 x;

    switch (sense) {
    case LEFT:
        for (x = 0; x <= LCD_COLS - 1; x++) { // Recorre la foto por columnas de izquierda a derecha
            lcd_shift(LEFT, 0, LCD_COLS - 1, 0, LCD_ROWS - 1); // Desplaza toda la pantalla una columna a la izquierda
            lcd_putColumn(LCD_COLS - 1, photo, x); // Visualiza la columna de la foto que corresponde en la ultima columna de la pantalla
            sw_delay_ms(delay);
        }
        break;
    case RIGHT:
        for (x = LCD_COLS - 1; x >= 0; x--) {
            lcd_shift(RIGHT, 0, LCD_COLS - 1, 0, LCD_ROWS - 1);
            lcd_putColumn(0, photo, x);
            sw_delay_ms(delay);
        }
        break;
    case UP:
        for (x = 0; x <= LCD_ROWS - 1; x++) {
            lcd_shift(UP, 0, 0, 0, LCD_ROWS);
            lcd_putRow(LCD_ROWS - 1, photo, x);
            sw_delay_ms(delay);
        }
        break;
    case DOWN:
        for (x = LCD_ROWS - 1; x >= 0; x--) {
            lcd_shift(DOWN, 0, 0, 0, LCD_ROWS - 1);
            lcd_putRow(0, photo, x);
            sw_delay_ms(delay);
        }
        break;
    }
}
/*
 ** Efecto barrido: La nueva imagen se superpone progresivamente sobre la imagen mostrada desde un lateral al opuesto
 */

void efectoBarrido(uint8 *photo, uint8 sense) {
	int16 x;

	switch (sense) {
	case LEFT:
		for (x = 0; x <= LCD_COLS - 1; x++) { // Recorre la foto por columnas de izquierda a derecha
			lcd_putColumn(x, photo, x); // Visualiza la columna de la foto que corresponde en la ultima columna de la pantalla
			sw_delay_ms(delay);
		}
		break;
	case RIGHT:
		for (x = LCD_COLS - 1; x >= 0; x--) {
			lcd_putColumn(x, photo, x);
			sw_delay_ms(delay);
		}
		break;
	case UP:
		for (x = LCD_ROWS - 1; x >= 0; x--) {
			lcd_putRow(x, photo, x);
			sw_delay_ms(delay);
		}
		break;
	case DOWN:
		for (x = 0; x <= LCD_ROWS - 1; x++) {
			lcd_putRow(x, photo, x);
			sw_delay_ms(delay);
		}
		break;
	}
}

/*
 ** Efecto revelado: La nueva imagen aparece conforme la imagen mostrada desaparece haciendo scroll
 */

void efectoRevelado(uint8 *photo, uint8 sense) {
    int16 x;

    switch (sense) {
    case LEFT:
        for (x = LCD_COLS - 1; x >= 0; x--) {
            lcd_shift(LEFT, 0, x, 0, LCD_ROWS - 1);
            lcd_putColumn(x, photo, x);
            sw_delay_ms(delay);
        }
        break;
    case RIGHT:
        for (x = 0; x < LCD_COLS; x++) {
            lcd_shift(RIGHT, x, LCD_COLS - 1, 0, LCD_ROWS - 1);
            lcd_putColumn(x, photo, x);
            sw_delay_ms(delay);
        }
        break;
    case UP:
        for (x = LCD_ROWS - 1; x >= 0; x--) {
            lcd_shift(UP, 0, 0, 0, x);
            lcd_putRow(x, photo,x);
            sw_delay_ms(delay);
        }
        break;
    case DOWN:
        for (x = 0; x <= LCD_ROWS - 1; x++) {
            lcd_shift(DOWN, 0, 0, x, LCD_ROWS - 1);
            lcd_putRow(x, photo, x);
            sw_delay_ms(delay);
        }
        break;
    }
}

void efectoDivisionSaliente(uint8 *photo, uint8 sense) {
	int16 p1, p2;
	if (sense == UP || sense == DOWN) {
		p1 = LCD_ROWS / 2;
		p2 = p1 - 1;
		while (p2 >= 0 && p1 <= LCD_ROWS - 1) {
			lcd_putRow(p1, photo, p1);
			lcd_putRow(p2, photo, p2);
			p2--;
			p1++;
			sw_delay_ms(delay);
		}
	} else {
		p1 = LCD_COLS / 2;
		p2 = p1 - 1;
		while (p2 >= 0 && p1 <= LCD_COLS - 1) {
			lcd_putColumn(p1, photo, p1);
			lcd_putColumn(p2, photo, p2);
			p2--;
			p1++;
			sw_delay_ms(delay);
		}
	}
}

void efectoDivisionEntrante(uint8 *photo, uint8 sense) {
	int16 p1, p2;
	if (sense == UP || sense == DOWN) {
		p1 = 0;
		p2 = LCD_ROWS - 1;
		while (p1 < p2) {
			lcd_putRow(p1, photo, p1);
			lcd_putRow(p2, photo, p2);
			p2--;
			p1++;
			sw_delay_ms(delay);
		}
	} else {
		p1 = 0;
		p2 = LCD_COLS - 1;
		while (p1 < p2) {
			lcd_putColumn(p1, photo, p1);
			lcd_putColumn(p2, photo, p2);
			p2--;
			p1++;
			sw_delay_ms(delay);
		}
	}
}
void efectoCuadradoEntrante(uint8 *photo, uint8 sense) {
	int16 fi, ff, ci, cf;
	fi = 0;
	ci = 0;
	ff = LCD_ROWS - 1;
	cf = LCD_COLS - 1;
	while (cf > ci) {
		lcd_putColumn(ci, photo, ci);
		lcd_putColumn(cf, photo, cf);
		if (ff > fi) {
			lcd_putRow(fi, photo, fi);
			lcd_putRow(ff, photo, ff);
			ff--;
			fi++;
		}
		cf--;
		ci++;
		sw_delay_ms(delay);
	}
}
void lcd_putPartColumn(int16 col, int16 rowOri, int16 rowDest, uint8* photo) {
	int16 y;
	for (y = rowOri; y <= rowDest; y++)
		lcd_buffer[(y * LCD_COLS) + col] = photo[(y * LCD_COLS) + col];
}
void lcd_putPartRow(int16 row, int16 colOri, int16 colDest, uint8* photo) {
	int16 x;
	for (x = colOri; x <= colDest; x++)
		lcd_buffer[(row * LCD_COLS) + x] = photo[(row * LCD_COLS) + x];
}
void efectoCruz(uint8 *photo, uint8 sense) {
	int16 ci, cd, fi, fd;
	ci = LCD_COLS / 2 - 1;
	cd = ci + 1;
	fi = LCD_ROWS / 2 - 1;
	fd = fi + 1;
	while (ci >= 0) {
		lcd_putColumn(ci, photo, ci);
		lcd_putColumn(cd, photo, cd);
		if (fi >= 0) {
			lcd_putRow(fi, photo, fi);
			lcd_putRow(fd, photo, fd);
			fi--;
			fd++;
		}
		ci--;
		cd++;
		sw_delay_ms(delay);
	}
}
void efectoCuadradoSaliente(uint8 *photo, uint8 sense) {
	int16 xi, xf, yi, yf;
	xf = LCD_COLS / 2;
	xi = xf - 1;
	yf = LCD_ROWS / 2;
	yi = yf - 1;
	while (yi >= 0) {
		if (xi >= 0) {
			lcd_putPartColumn(xi, yi, yf, photo);
			lcd_putPartColumn(xf, yi, yf, photo);
			lcd_putPartRow(yi, xi, xf, photo);
			lcd_putPartRow(yf, xi, xf, photo);
			xi--;
			xf++;
		} else {
			lcd_putRow(yi, photo, yi);
			lcd_putRow(yf, photo, yf);
		}
		yi--;
		yf++;
		sw_delay_ms(delay);
	}
}

void efectoBarras(uint8 *photo, uint8 sense) {
	int16 x, p;
	if (sense == UP || sense == DOWN) {
		uint8 lcd_pintado[LCD_ROWS] = { 0 };
		for (x = 0; x < LCD_ROWS; x++) {
			while (lcd_pintado[(p = rand() % LCD_ROWS)]==1);
			lcd_pintado[p]=1;
			lcd_putRow(p,photo,p);
			sw_delay_ms(delay);
		}
	}
	else {
		uint8 lcd_pintado[LCD_COLS]= {0};
		for(x=0; x < LCD_COLS;x++) {
			while(lcd_pintado[(p = rand()%LCD_COLS)]==1);
			lcd_pintado[p]=1;
			lcd_putColumn(p,photo,p);
			sw_delay_ms(delay);
		}
	}
}
void efectoDesvanecer(uint8 *photo, uint8 sense) {
	lcd_full_color(LIGHTGRAY);
	sw_delay_ms(delay);
	lcd_full_color(DARKGRAY);
	sw_delay_ms(delay);
	lcd_full_color(BLACK);
	sw_delay_ms(delay);
	lcd_putPhoto(photo);
}
void lcd_full_color(uint16 color) {
	int16 x, y;
	for (y = 0; y < LCD_ROWS; y++)
		for (x = 0; x < LCD_COLS; x++)
			lcd_buffer[(y * LCD_COLS) + x] = color;
}
void efectoFlash(uint8 *photo, uint8 sense) { //meh
	int16 x;
	uint8 aux[LCD_BUFFER_SIZE];

	lcd_full_color(WHITE);
	sw_delay_ms(2);

	for (x = 0; x <= 16; x = x + 4) {
		photosMaxColor(photo, aux, x);
		lcd_putPhoto(aux);
		sw_delay_ms(delay);
	}

	lcd_putPhoto(photo);
}
void photosMaxColor(uint8* photo, uint8* aux, uint16 color) {
	int16 x, y;

	for (y = 0; y < LCD_ROWS; y++) {
		for (x = 0; x < LCD_COLS; x++) {
			if (photo[y * LCD_COLS + x] > color) {
				aux[y * LCD_COLS + x] = color;
			} else {
				aux[(y * LCD_COLS) + x] = photo[(y * LCD_COLS) + x];
			}
		}
	}
}
void putSquare(int x, int y, int tam, uint8 *photo){
	int16 fil, col;
	for (fil = y; fil < y+tam; fil++)
		for (col = x; col < x+tam; col++)
			lcd_buffer[(fil * LCD_COLS) + col] = photo[(fil * LCD_COLS) + col];
}
void efectoDisolver(uint8* photo, uint8 sense) {
	uint8 cx[150],cy[150];
	boolean pintado[150]={FALSE};
	int16 x,y,c,pos;
	c=0;
	for(y = 0; y < LCD_ROWS; y+=16){
		for(x=0;x<LCD_COLS;x+=16){
			cx[c]=x;
			cy[c]=y;
			c++;
		}
	}
	for(c=0; c<150;c++){
		while(pintado[pos=rand()%150]);
		pintado[pos]=TRUE;
		putSquare(cx[pos],cy[pos], 16,photo);
		sw_delay_ms(delay);
	}
}
void efectoAleatorio(uint8 *photo, uint8 sense) {
	uint8 e = rand() % (15); //cualquier efecto menos el aleatorio, colocado al final del array
	(*functions[e])(photo, sense);
}

void isr_pbs(void) {
	switch (pb_scan()) {
	case PB_LEFT:
		delay = delay + 2 > 50 ? 50 : delay + 2;
		EXTINTPND = BIT_LEFTPB;
		break;
	case PB_RIGHT:
		delay = delay - 2 < 0 ? 0 : delay - 2;
		EXTINTPND = BIT_RIGHTPB;
		break;
	default:
		EXTINTPND = BIT_LEFTPB | BIT_RIGHTPB;
		break;
	}
	flagPbs = TRUE;
	I_ISPC = BIT_PB;
}
void isr_keypad(void) {
	switch (keypad_scan()) {
	case KEYPAD_KEY0:
		efecto = functions[0];
		break;
	case KEYPAD_KEY1:
		efecto = functions[1];
		break;
	case KEYPAD_KEY2:
		efecto = functions[2];
		break;
	case KEYPAD_KEY3:
		efecto = functions[3];
		break;
	case KEYPAD_KEY4:
		efecto = functions[4];
		break;
	case KEYPAD_KEY5:
		efecto = functions[5];
		break;
	case KEYPAD_KEY6:
		efecto = functions[6];
		break;
	case KEYPAD_KEY7:
		efecto = functions[7];
		break;
	case KEYPAD_KEY8:
		efecto = functions[8];
		break;
	case KEYPAD_KEY9:
		efecto = functions[9];
		break;
	case KEYPAD_KEYA:
		efecto = functions[10];
		break;
	case KEYPAD_KEYB:
		efecto = functions[11];
		break;
	case KEYPAD_KEYC:
		efecto = functions[12];
		break;
	case KEYPAD_KEYD:
		efecto = functions[13];
		break;
	case KEYPAD_KEYE:
		efecto = functions[14];
		break;
	case KEYPAD_KEYF:
		stop=!stop;
		break;
	default:
		break;
	}
	flagKeypad = TRUE;
	I_ISPC = BIT_KEYPAD;
}
